A sample demonstrating usage of OCCT 3D Viewer within a window created using GLFW.

Platforms: Windows, macOS, Linux
Required: glfw
