//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Geometry.rc
//
#define IDOK2                           3
#define IDR_TYPE                        18
#define IDR_Samples2DTYPE               130
#define IDR_Samples3DCollectorTYPE      133
#define IDR_CHILD2D                     139
#define IDR_MAINFRAME2                  141
#define ID_BUTTON_Test_1                800
#define ID_BUTTON_Test_2                801
#define ID_BUTTON_Test_3                802
#define ID_BUTTON_Test_4                803
#define ID_BUTTON_Test_5                804
#define ID_BUTTON_Test_6                805
#define ID_BUTTON_Test_7                806
#define ID_BUTTON_Test_8                807
#define ID_BUTTON_Test_9                808
#define ID_BUTTON_Test_10               809
#define ID_BUTTON_Test_23               810
#define ID_BUTTON_Test_22               811
#define ID_BUTTON_Test_32               812
#define ID_BUTTON_Test_11               813
#define ID_BUTTON_Test_12               814
#define ID_BUTTON_Test_13               815
#define ID_BUTTON_Test_14               816
#define ID_BUTTON_Test_15               817
#define ID_BUTTON_Test_16               818
#define ID_BUTTON_Test_17               819
#define ID_BUTTON_Test_18               820
#define ID_BUTTON_Test_19               821
#define ID_BUTTON_Test_20               822
#define ID_BUTTON_Test_21               823
#define ID_BUTTON_Test_24               824
#define ID_BUTTON_Test_25               825
#define ID_BUTTON_Test_26               826
#define ID_BUTTON_Test_27               827
#define ID_BUTTON_Test_28               828
#define ID_BUTTON_Test_29               829
#define ID_BUTTON_Test_30               830
#define ID_BUTTON_Test_31               831
#define ID_BUTTON_Test_33               832
#define ID_BUTTON_Test_34               833
#define ID_BUTTON_Test_35               834
#define ID_BUTTON_Test_36               835
#define ID_BUTTON_Test_37               836
#define ID_BUTTON_Test_38               837
#define ID_BUTTON_Test_39               838
#define ID_BUTTON_Test_40               839
#define ID_BUTTON_Test_41               840
#define ID_BUTTON_Test_42               841
#define ID_BUTTON_Test_43               842
#define ID_BUTTON_Test_44               843
#define ID_BUTTON_Test_45               844
#define ID_BUTTON_Test_46               845
#define ID_BUTTON_Test_47               846
#define ID_BUTTON_Test_48               847
#define ID_BUTTON_Test_49               848
#define ID_BUTTON_Test_50               849
#define ID_BUTTON_Test_51               850
#define ID_HI                           853
#define ID_Create_Sol                   854
#define ID_BUTTON855                    855
#define ID_BUTTON_Simplify              855
#define ID_BUTTONGridRectLines          40030
#define ID_BUTTONGridRectPoints         40031
#define ID_BUTTONGridCircLines          40032
#define ID_BUTTONGridCircPoints         40033
#define ID_BUTTONGridValues             40034
#define ID_BUTTONGridCancel             40035
#define ID_WINDOW_NEW2D                 40150

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         856
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
